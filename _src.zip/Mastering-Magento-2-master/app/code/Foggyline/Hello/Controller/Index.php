<?php

namespace Foggyline\Hello\Controller;

abstract class Index extends \Magento\Framework\App\Action\Action
{

}
